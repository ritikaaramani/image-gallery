# app/modules/search/__init__.py
from . import router
